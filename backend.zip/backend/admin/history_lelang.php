<?php
session_start();
include 'connection.php';

// Validasi Login
if (!isset($_SESSION['id_petugas'])) {
    header("Location: index.php");
    exit;
}

$id_level = $_SESSION['id_level']; 

// Kalau ada id_lelang di URL (datang dari tombol "Detail" di Laporan/Kelola Lelang),
// tampilkan kartu detail barang + HANYA history penawaran untuk barang/sesi lelang itu saja
$filter_aktif = false;
$nama_barang_filter = '';
$barang = null; // data lengkap barang untuk kartu detail

if (isset($_GET['id_lelang'])) {
    $filter_aktif = true;
    $id_lelang_filter = (int) $_GET['id_lelang'];

    // Ambil data lengkap barang + lelang untuk kartu detail di atas
    $query_barang = "SELECT tb_lelang.*, tb_barang.nama_barang, tb_barang.harga_awal, 
                             tb_barang.deskripsi_barang, tb_barang.foto,
                             tb_masyarakat.nama_lengkap AS nama_pemenang
                      FROM tb_lelang 
                      JOIN tb_barang ON tb_lelang.id_barang = tb_barang.id_barang 
                      LEFT JOIN tb_masyarakat ON tb_lelang.id_user = tb_masyarakat.id_user
                      WHERE tb_lelang.id_lelang = ?";
    $stmt_barang = mysqli_prepare($conn, $query_barang);
    mysqli_stmt_bind_param($stmt_barang, "i", $id_lelang_filter);
    mysqli_stmt_execute($stmt_barang);
    $result_barang = mysqli_stmt_get_result($stmt_barang);
    $barang = mysqli_fetch_assoc($result_barang);

    if ($barang) {
        $nama_barang_filter = $barang['nama_barang'];
    }

    // Ambil riwayat penawaran untuk barang/sesi lelang ini
    $query = "SELECT history_lelang.*, tb_barang.nama_barang, tb_barang.foto, tb_masyarakat.nama_lengkap 
              FROM history_lelang 
              JOIN tb_lelang ON history_lelang.id_lelang = tb_lelang.id_lelang
              JOIN tb_barang ON tb_lelang.id_barang = tb_barang.id_barang
              LEFT JOIN tb_masyarakat ON history_lelang.id_user = tb_masyarakat.id_user
              WHERE history_lelang.id_lelang = ?
              ORDER BY history_lelang.penawaran_harga DESC";
    $stmt = mysqli_prepare($conn, $query);
    mysqli_stmt_bind_param($stmt, "i", $id_lelang_filter);
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);
} else {
    // Tidak ada id_lelang -> tampilkan semua history seperti biasa
    $query = "SELECT history_lelang.*, tb_barang.nama_barang, tb_barang.foto, tb_masyarakat.nama_lengkap 
              FROM history_lelang 
              JOIN tb_lelang ON history_lelang.id_lelang = tb_lelang.id_lelang
              JOIN tb_barang ON tb_lelang.id_barang = tb_barang.id_barang
              LEFT JOIN tb_masyarakat ON history_lelang.id_user = tb_masyarakat.id_user
              ORDER BY history_lelang.id_history DESC";
    $result = mysqli_query($conn, $query);
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>History Lelang - E-Lelang</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        body {
            background-color: #f4f7fc;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }
        .sidebar {
            height: 100vh;
            background: linear-gradient(180deg, #0d6efd 0%, #0b5ed7 100%);
            color: white;
            position: fixed;
            width: 260px;
            top: 0;
            left: 0;
            padding-top: 25px;
            box-shadow: 4px 0 10px rgba(0,0,0,0.05);
        }
        .sidebar a {
            color: rgba(255, 255, 255, 0.85);
            text-decoration: none;
            display: flex;
            align-items: center;
            padding: 12px 22px;
            font-size: 0.95rem;
            transition: all 0.3s ease;
            margin: 4px 12px;
            border-radius: 8px;
        }
        .sidebar a:hover, .sidebar a.active {
            background-color: rgba(255, 255, 255, 0.15);
            color: white;
            transform: translateX(4px);
        }
        .main-content {
            margin-left: 260px;
            padding: 30px;
        }
        .card-custom {
            border: none;
            border-radius: 12px;
            box-shadow: 0 0.125rem 0.25rem rgba(0, 0, 0, 0.075);
            background: #ffffff;
        }
        .table th {
            font-weight: 600;
            color: #495057;
            background-color: #f8f9fa !important;
            border-bottom: 2px solid #dee2e6;
        }
        .table td {
            vertical-align: middle;
            color: #212529;
        }
        .img-thumb {
            width: 45px;
            height: 45px;
            object-fit: cover;
            border-radius: 8px;
            box-shadow: 0 2px 5px rgba(0,0,0,0.1);
        }
        .foto-detail {
            width: 100%;
            max-height: 340px;
            object-fit: cover;
            border-radius: 12px;
            background-color: #e9ecef;
        }
    </style>
</head>
<body>

<!-- Sidebar -->
<div class="sidebar d-flex flex-column">
    <h4 class="text-center fw-bold mb-4"><i class="fas fa-gavel me-2"></i>E-LELANG</h4>
    
    <div class="flex-grow-1">
        <a href="dashboard.php"><i class="fas fa-tachometer-alt me-3 fa-fw"></i> Dashboard</a>
        <a href="pendataan_barang.php"><i class="fas fa-box me-3 fa-fw"></i> Pendataan Barang</a>
        <a href="kelola_lelang.php"><i class="fas fa-balance-scale me-3 fa-fw"></i> Kelola Lelang</a>
        <a href="history_lelang.php" class="active"><i class="fas fa-history me-3 fa-fw"></i> History Lelang</a>
        <a href="laporan.php"><i class="fas fa-file-alt me-3 fa-fw"></i> Generate Laporan</a>
        <a href="pendataan_masyarakat.php"><i class="fas fa-users me-3 fa-fw"></i> Data Masyarakat</a>

        <?php if ($id_level == 1) : ?>
            <hr class="text-white-50 mx-4 my-3">
            <small class="text-warning px-4 fw-bold" style="font-size: 0.75rem; letter-spacing: 0.5px;">MENU ADMIN</small>
            <a href="registrasi_petugas.php"><i class="fas fa-user-shield me-3 fa-fw"></i> Registrasi Petugas</a>
        <?php endif; ?>
    </div>
    
    <div class="p-3 mb-2">
        <a href="logout.php" class="btn btn-danger w-100 text-white shadow-sm py-2 rounded-pill"><i class="fas fa-sign-out-alt me-2"></i> Logout</a>
    </div>
</div>

<!-- Main Content -->
<div class="main-content">
    <div class="bg-white p-3 px-4 rounded-4 shadow-sm mb-4 d-flex justify-content-between align-items-center">
        <div>
            <?php if ($filter_aktif) : ?>
                <a href="laporan.php" class="text-decoration-none text-secondary small">
                    <i class="fas fa-arrow-left me-1"></i> Kembali ke Laporan
                </a>
            <?php endif; ?>
            <h5 class="mb-0 fw-bold text-dark <?= $filter_aktif ? 'mt-1' : ''; ?>">
                <?php if ($filter_aktif && $nama_barang_filter) : ?>
                    History Penawaran: <?= htmlspecialchars($nama_barang_filter); ?>
                <?php else : ?>
                    History Penawaran Lelang
                <?php endif; ?>
            </h5>
            <small class="text-muted">
                <?php if ($filter_aktif) : ?>
                    Menampilkan riwayat penawaran untuk barang ini saja, diurutkan dari harga tertinggi
                <?php else : ?>
                    Daftar riwayat harga yang ditawarkan oleh masyarakat
                <?php endif; ?>
            </small>
        </div>
        <?php if ($filter_aktif) : ?>
            <a href="history_lelang.php" class="btn btn-outline-secondary btn-sm rounded-pill px-3">
                <i class="fas fa-list me-1"></i> Lihat Semua History
            </a>
        <?php endif; ?>
    </div>

    <?php if ($filter_aktif && $barang) : ?>
        <?php
            $fotoDetail = (!empty($barang['foto']) && file_exists("img/" . $barang['foto']))
                ? "img/" . htmlspecialchars($barang['foto'])
                : "https://via.placeholder.com/600x400?text=No+Image";
        ?>
        <!-- Kartu Detail Barang, gaya sama seperti detail_barang.php -->
        <div class="card card-custom p-4 mb-4">
            <div class="row g-4">
                <div class="col-md-5">
                    <img src="<?= $fotoDetail; ?>" class="foto-detail" alt="<?= htmlspecialchars($barang['nama_barang']); ?>">
                </div>
                <div class="col-md-7 d-flex flex-column">
                    <h3 class="fw-bold text-primary mb-3">
                        <i class="fas fa-box me-2"></i><?= htmlspecialchars($barang['nama_barang']); ?>
                    </h3>
                    <p class="text-muted mb-4"><?= nl2br(htmlspecialchars($barang['deskripsi_barang'])); ?></p>

                    <div class="row">
                        <div class="col-sm-4 mb-3">
                            <span class="text-secondary small d-block">Harga Awal</span>
                            <span class="fw-bold text-dark fs-5">Rp <?= number_format($barang['harga_awal'], 0, ',', '.'); ?></span>
                        </div>
                        <div class="col-sm-4 mb-3">
                            <span class="text-secondary small d-block">Harga Akhir</span>
                            <span class="fw-bold text-success fs-5"><?= $barang['harga_akhir'] ? 'Rp ' . number_format($barang['harga_akhir'], 0, ',', '.') : '-'; ?></span>
                        </div>
                        <div class="col-sm-4 mb-3">
                            <span class="text-secondary small d-block">Tgl Lelang</span>
                            <span class="fw-semibold text-dark"><i class="far fa-calendar-alt me-1"></i> <?= $barang['tgl_lelang']; ?></span>
                        </div>
                    </div>

                    <div class="d-flex align-items-center gap-3 mt-auto">
                        <?php if ($barang['status'] == 'dibuka') : ?>
                            <span class="badge bg-success-subtle text-success border border-success-subtle px-3 py-2 rounded-pill">Dibuka</span>
                        <?php else : ?>
                            <span class="badge bg-secondary-subtle text-secondary border border-secondary-subtle px-3 py-2 rounded-pill">Ditutup</span>
                        <?php endif; ?>

                        <?php if (!empty($barang['nama_pemenang'])) : ?>
                            <span class="fw-semibold text-dark"><i class="fas fa-user-check text-success me-1"></i> Pemenang: <?= htmlspecialchars($barang['nama_pemenang']); ?></span>
                        <?php else : ?>
                            <span class="text-muted fst-italic">Belum ada pemenang</span>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    <?php endif; ?>

    <div class="card card-custom p-4">
        <div class="table-responsive">
            <table class="table table-hover align-middle mb-0">
                <thead>
                    <tr>
                        <th class="py-3 text-center" style="width: 5%;">No</th>
                        <th class="py-3 text-center" style="width: 8%;">Foto</th>
                        <th class="py-3" style="width: 27%;">Nama Barang</th>
                        <th class="py-3" style="width: 30%;">Nama Penawar</th>
                        <th class="py-3" style="width: 30%;">Harga Ditawar</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if ($result && mysqli_num_rows($result) > 0) : ?>
                        <?php $no = 1; while ($row = mysqli_fetch_assoc($result)) : ?>
                        <?php
                            $fotoPath = (!empty($row['foto']) && file_exists("img/" . $row['foto']))
                                ? "img/" . htmlspecialchars($row['foto'])
                                : null;
                        ?>
                        <tr>
                            <td class="text-center fw-semibold text-secondary"><?= $no++; ?></td>
                            <td class="text-center">
                                <?php if ($fotoPath) : ?>
                                    <img src="<?= $fotoPath; ?>" alt="<?= htmlspecialchars($row['nama_barang']); ?>" class="img-thumb">
                                <?php else : ?>
                                    <span class="badge bg-secondary">No Image</span>
                                <?php endif; ?>
                            </td>
                            <td class="fw-bold text-dark"><?= htmlspecialchars($row['nama_barang']); ?></td>
                            <td><?= htmlspecialchars($row['nama_lengkap'] ?? 'Masyarakat'); ?></td>
                            <td><span class="text-success fw-semibold">Rp <?= number_format($row['penawaran_harga'], 0, ',', '.'); ?></span></td>
                        </tr>
                        <?php endwhile; ?>
                    <?php else : ?>
                        <tr>
                            <td colspan="5" class="text-center text-muted py-4">
                                <div class="py-3">
                                    <i class="fas fa-history fa-3x text-secondary mb-3 opacity-50"></i>
                                    <p class="mb-0">
                                        <?php if ($filter_aktif) : ?>
                                            Belum ada penawaran untuk barang ini.
                                        <?php else : ?>
                                            Belum ada riwayat penawaran lelang.
                                        <?php endif; ?>
                                    </p>
                                </div>
                            </td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>